
==============================================================================
This file is intended to help you get started with the WebBuilder.

For more information see http://www.putdb.com
==============================================================================


What is WebBuilder?
==============================================================================

WebBuilder is an open source rapid web application development platform.

For license information see http://www.putdb.com/main?xwl=license


What is in this package?
==============================================================================

misc                        miscellaneous files. 

project                     Eclipse project of the WebBuilder

source                      source code of the WebBuilder

wb                          application folder for web application server. 

license.txt                 license file of the WebBuilder

readme.txt                  this file.


How do I install WebBuilder on my web application server?
==============================================================================

1, Install JAVA web application server and prepare a database of any types,

   create a JNDI entry for the database connection, ensure the JNDI is

   available, WebBuilder will use the database.

2, Extract application folder wb from the webbuilder.zip file and distribute

   to the web application server.

   For example, if you use Tomcat, you should copy wb folder to webapps/wb.

3, Open web browser and browse [http://ip:port/wb] to open the install wizard

   to complete the installation.

   For example, browse http://localhost:8080/wb

4, Login to the system with default administrator account.

   The administrator's default username is admin, password is admin.


What should I do if I encounter a problem?
==============================================================================

Please join our developer community:

    http://www.putdb.com

Help is available via the WebBuilder forum:

    http://www.putdb.com/main?xwl=bbs

Docs is available in our website:

    http://www.putdb.com/main?xwl=docs

If you have any questions, please contact us with e-mail:

    contact@putdb.com